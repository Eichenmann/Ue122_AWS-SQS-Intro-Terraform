exports.handler = async (event) => {
    console.log("SQS START: --------------");
    console.log(event);
    console.log("SQS END: --------------");
};
